-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 08, 2022 at 05:56 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `event`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE IF NOT EXISTS `activity` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `start` varchar(10) NOT NULL,
  `end` varchar(10) NOT NULL,
  `month` varchar(8) NOT NULL,
  `year` varchar(5) NOT NULL,
  PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`activity_id`, `title`, `description`, `start`, `end`, `month`, `year`) VALUES
(1, 'DANCE INDIA ', 'SVN UNIVERSITY ORGANIZED DID,EVERY ONE CAN PARTICIPATE BELOW 25 yrs', '2021-08-15', '2021-08-30', 'Aug', '2021'),
(3, ' Kavi samelan', 'Vichar Sanstha organizing a kavi samelan at ravindra bhavan special guest kumar viswas contact for pass', '2020-03-02', '2020-05-02', 'Mar', '2020'),
(4, 'Tech skill competition 2021', 'Tech skill competition 2021 by BTIRT College ', '2021-08-17', '2021-08-27', 'Aug', '2021');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(12) NOT NULL,
  `name` varchar(40) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `name`) VALUES
(2, 'lucky', 'admin', 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table ` aplicants`
--

CREATE TABLE IF NOT EXISTS ` aplicants` (
  `id` int(8) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `age` varchar(25) NOT NULL,
  `address` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `company_name` varchar(55) NOT NULL,
  `cv` varchar(55) NOT NULL,
  `gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table ` aplicants`
--


-- --------------------------------------------------------

--
-- Table structure for table `fill_details`
--

CREATE TABLE IF NOT EXISTS `fill_details` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(40) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `file` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `fill_details`
--

INSERT INTO `fill_details` (`id`, `company_name`, `first_name`, `last_name`, `email`, `gender`, `file`) VALUES
(4, 'techzim', 'leo', 'mutema', 'muteam@gmail.com', 'Female', '444.PNG'),
(5, 'gtech', 'mutoro', 'mutoro', 'mutorok@gmail.com', 'Female', '444.PNG'),
(16, 'lllll', 'ddd', 'sshgsh', 'sssksjjs', 'Male', 'Capture 1.PNG'),
(17, 'yththh', 'figffjjkf', 'ffjeofhoe', 'dfhjhjdfdf', 'Male', 'funny.PNG'),
(26, 'eee', 'eee', 'eeeeaa', 'aaaa@gmail.com', '', ''),
(28, 'fff', 'dd', 'dd', 'aaaa@gmail.com', 'Male', 'did u.jpg'),
(31, 'lolo', 'jghjj', 'gfgg', 'aaaa@gmail.com', 'Female', '1.jpg'),
(33, 'lolo', 'lll', 'gfg', 'aaaa@gmail.com', 'Male', '1.jpg'),
(34, 'techzim', 'libert', 'liberty', 'aaaa@gmail.com', 'Female', '1.jpg'),
(35, 'comapp', 'asa', 'aaa', 'aaaa@gmail.com', 'Female', 'libary features 1.PNG'),
(40, ' dfddfd', 'eeee', 'dddd', 'ddd', 'Male', 'Capture 2.PNG'),
(42, ' dfddfd', 'eeee', 'dddd', 'hhhh@m.b', 'Female', 'Capture 2.PNG'),
(43, ' dramcache ', 'liberty', 'chatikobo', 'vbvb@gmail.com', 'Male', '1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `registered_users`
--

CREATE TABLE IF NOT EXISTS `registered_users` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(25) NOT NULL,
  `phoneno` bigint(20) NOT NULL,
  `email` varchar(55) NOT NULL,
  `gender` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `registered_users`
--

INSERT INTO `registered_users` (`id`, `user_name`, `first_name`, `last_name`, `password`, `phoneno`, `email`, `gender`) VALUES
(1, 'neha', 'jain', 'jain', 'events', 888877777, 'event@gmail.com', 'Female'),
(2, 'vivek', 'vivek', 'jain', 'ff', 982769999, 'atgerv@gmail.com', 'Male'),
(5, 'ram', 'kumar', 'singh', 'atherv', 9829987888, 'ramsingh@gmail.com', 'male'),
(11, 'seema', 'kumar', 'sen', 'atherv', 9823456777, 'seemasen@gmail.com', 'female'),
(12, 'geeta', 'kumar', 'jain', 'atherv', 9988776655, 'seema@gmail.com', 'female'),
(15, 'jayaG', 'jaya ', 'jain', 'atherv', 9898767654, 'jaya@gmail.com', 'Female'),
(16, 'nehaG', 'neha', 'jain', 'atherfv', 8878788872, 'nrehajain@gmail.com', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `firstname` varchar(40) NOT NULL,
  `middlename` varchar(40) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `year` varchar(2) NOT NULL,
  `section` varchar(1) NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `student_id`, `firstname`, `middlename`, `lastname`, `year`, `section`, `photo`) VALUES
(3, 21201455, 'Daw', 'asd', 'asd', 'II', 'A', 'default.png');

-- --------------------------------------------------------

--
-- Table structure for table `tblfinal`
--

CREATE TABLE IF NOT EXISTS `tblfinal` (
  `fid` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `eventdesc` varchar(100) NOT NULL,
  `whtsup` bigint(10) NOT NULL,
  `pic` varchar(255) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tblfinal`
--

INSERT INTO `tblfinal` (`fid`, `username`, `eventdesc`, `whtsup`, `pic`) VALUES
(1, ' suman', ' Btirt college event', 7878989878, '112.jpg');

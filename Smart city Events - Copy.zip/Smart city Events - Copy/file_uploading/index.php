<?php
include_once 'dbconfig.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Sagar Events</title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<div id="header">
<label>Sagar Events </label>
</div>
<div id="body">
	<h1>Thanks for booking we catch you soon...! 
    
    
    
    </h1>
    <a href="../index.php">click.
        |HOME</a>
</div>
<div id="footer">
<label>By <a href="#">sagarevents@gmail.com</a></label>
</div>
</body>
</html>
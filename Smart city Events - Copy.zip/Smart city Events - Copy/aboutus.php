<div id = "aboutus" class = "tab-pane fade">
	<div class = "alert alert-success"><center><h3>VISION</h3></center></div>
	<h4 style = "text-indent:50px;">Excellence in producing highly skilled, well qualified and globally  Information to every one</h4>
	<br />
	<div class = "alert alert-success"><center><h3>MISSION</h3></center></div>
	<h4 style = "text-indent:50px;"> to provide events info for what humour and talent are there in sagar.Need to show every single information to all</h4>
	<br />
	<div class = "alert alert-success"><center><h3>OBJECTIVE</h3></center></div>
	<ol>
		<li><h4> knowledge and skills that would prepare graduate in computing professions who are well in there  nature</h4></li>
		<li><h4>Prepare students to be  professionals and be expert on design and implementation of skills Systems for business processes</h4></li>
		<li><h4>Be proficient in designing and showing  activities</h4></li>
		<li><h4>Manifest interpersonal, communications, and leadership skills through significant curricular, co-curricular and extra-curricular activities</h4></li>
		<li><h4>Virtues social consciousness through active participation in research, extension and professional organization</h4></li>
	</ol>
</div>
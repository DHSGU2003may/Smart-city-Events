<html>
<body>
<?php
$con = mysql_connect("localhost","root","","event");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("event", $con);

 
$sql="INSERT INTO tblfinal (username,eventdesc,whtsup,pic)
VALUES
( '$_POST[username]','$_POST[eventdesc]','$_POST[whtsup]','$_POST[file]')";
 
if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
echo "<script>alert(' thank you for final registration...we will catch you soon on whtsup!');document.location='../index.php'</script>";
 
mysql_close($con)
?>
</body>
</html>
 
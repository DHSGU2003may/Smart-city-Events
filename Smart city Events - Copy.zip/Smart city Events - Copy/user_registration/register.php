<?php
	
if(isset($_POST['register-user'])){

$con = mysql_connect("localhost","root","","event");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("event", $con);

 
$query = "INSERT INTO registered_users (user_name,first_name,last_name, password,phoneno,email,gender) VALUES
	
( '$_POST[userName]','$_POST[firstName]','$_POST[lastName]','$_POST[password]','$_POST[phoneno]','$_POST[userEmail]','$_POST[gender]')";
 
if (!mysql_query($query,$con))
  {
  die('Error: ' . mysql_error());
  }

 }
echo "<script>alert(' thank you for registration...now login and complete your booking!');document.location='slogin.php'</script>";

mysql_close($con)


?>

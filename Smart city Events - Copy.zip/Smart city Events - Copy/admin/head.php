<nav class = "navbar navbar-default navbar-fixed-top" style="background-color:#f34344;">
	<div class = "container-fluid">
		<h2><marquee style="color:white;">City Events</marquee></h2>
	
<div>
</nav>
<?php
	$conn = new mysqli('localhost', 'root', '', 'event') or die(mysqli_error());
?>